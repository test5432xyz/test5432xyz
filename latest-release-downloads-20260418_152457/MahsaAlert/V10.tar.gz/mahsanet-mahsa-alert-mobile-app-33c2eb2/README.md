# Public Repository for Mahsa Alert Mobile App

## Support this project

Access to the right information at the right moment can save lives.

Support the project:
https://gofund.me/1f800b407

Your donation helps extend the reach of life-saving alerts and critical safety information.
